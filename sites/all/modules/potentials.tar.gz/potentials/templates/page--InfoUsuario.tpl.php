<?php
	header("Content-type: text/xml");

	//var_dump($response);
	//drupal_goto($response['return_url'], array('query'=>$response), 200);

?>

